package com.example.rastreador;

import java.util.ArrayList;

public class Mensageiro {

    private ArrayList<Mensagem> mensagens;

    public Mensageiro() {
        this.mensagens = new ArrayList<>();
    }

    public void novaMensagem(String de, String para, int tipo, String txtMsg, String fotoAnexa) {
        Mensagem msg = new Mensagem(de, para, tipo, txtMsg, fotoAnexa);
        mensagens.add(msg);

    }

    public void novaMensagem(String de, String para, int tipo, String txtMsg) {
        Mensagem msg = new Mensagem(de, para, tipo, txtMsg);
        mensagens.add(msg);
    }

    public ArrayList<Mensagem> getMensagens(String usuario) {
        Mensagem mensagem;
        ArrayList<Mensagem> msgsTemp = new ArrayList<>();

        for (int i = 0; i < mensagens.size(); i++) {
            mensagem = mensagens.get(i);
            String paraTemp = mensagem.getPara();
            if (paraTemp.equals(usuario)){
                msgsTemp.add(0, mensagem);
            }
        }
        return msgsTemp; // pode retornar tbm um  array de size() vazio
    }
}
