package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private String usuario;
    private Modelo modelo;
    private Mensageiro mensageiro;
    private ArrayList<Mensagem> mensagens;

    ///CODES:
    public int LOGIN_REQUEST = 1;
    public int USUARIO_REQUEST = 2;
    public int AREAS_REQUEST = 3;
    public int STATUS_REQUEST = 4;
    public int MENSAGEIRO_REQUEST = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usuario = "VAZIO";
        modelo = new Modelo();
        modelo.carregarDados();
        mensageiro = new Mensageiro();
        carregar();
    }

    public void carregar() {
        Intent login = new Intent(MainActivity.this, LoginActivity.class);
        login.putExtra("usuarios", modelo.getPessoasString());
        startActivityForResult(login, LOGIN_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_CANCELED) {
            finish();
        } else if (requestCode == LOGIN_REQUEST) {
            usuario = data.getStringExtra("retorno");
            if (usuario.equals("rastreador")) {
                carregarMensageiro(usuario);
            } else {
                carregarUsuario();
            }
        } else if (requestCode == USUARIO_REQUEST) {
            String retorno = data.getStringExtra("retorno");
            if (retorno.equals("btSair")) {
                carregar();
            } else if (retorno.equals("btEditarAreas")) {
                carregarAreas(0); //0=modoUsuario;
            } else if (retorno.equals("btStatus")) {
                carregarStatus();
            } else {
                //System.out.println("erro");
            }
        } else if (requestCode == AREAS_REQUEST) {
            String[] areasRetornadas = data.getStringArrayExtra("arrayAreas");
            int modoRetornado = data.getIntExtra("modo", 2345678);

            String msgRetorno = "Modo: " + String.valueOf(modoRetornado) + "; ";
            msgRetorno += "TamanhoArray: " + String.valueOf(areasRetornadas.length) + "; ";
            msgRetorno += "return String[] e modo; Sucesso! (sem alterar modelo ainda)";

            carregarUsuario();
        } else if (requestCode == STATUS_REQUEST) {
            int statusRetornado = data.getIntExtra("retorno", -1);
            if (statusRetornado == 0 || statusRetornado == 1) {
                modelo.setStatusUsuario(usuario, statusRetornado);
            } else if (statusRetornado == 2) {
                String fotoPath = data.getStringExtra("fotoPath");
                modelo.setStatusUsuario(usuario, statusRetornado, fotoPath);
                mensageiro.novaMensagem(usuario, "rastreador", 1, "Olá, Mundo!", fotoPath);
            }
            carregarUsuario();
        } else if (requestCode == MENSAGEIRO_REQUEST) {
            int retornoRetornado = data.getIntExtra("retorno", -1);

            if (retornoRetornado == 1) { // confirmar doente
                String userRetornado = data.getStringExtra("confirmarUser");
                modelo.setStatusRastreador(userRetornado, 2);
                carregarMensageiro("rastreador");
            } else if (retornoRetornado == 2){
                usuario = "VAZIO";
                carregar();
            }

        } else {
        }
    }

    private void carregarUsuario() {
        Pessoa pessoa = modelo.getPessoa(usuario);
        MapaDeRiscos mapa = modelo.getPessoaMapa(usuario);
        Intent carregarUsuario = new Intent(MainActivity.this, UsuarioActivity.class);

        //PESSOA:
        carregarUsuario.putExtra("nome", mapa.getNome());
        carregarUsuario.putExtra("status", pessoa.getStatus());
        carregarUsuario.putExtra("afastado", pessoa.getAfastado());
        carregarUsuario.putExtra("stsFoto", pessoa.getStsFoto());

        //MAPA:
        carregarUsuario.putExtra("nivelDoRisco", mapa.getNivelDoRisco());
        carregarUsuario.putExtra("p0", mapa.getP0());
        carregarUsuario.putExtra("p1", mapa.getP1());
        carregarUsuario.putExtra("p2", mapa.getP2());
        carregarUsuario.putExtra("a0", mapa.getA0());
        carregarUsuario.putExtra("a1", mapa.getA1());
        carregarUsuario.putExtra("a2", mapa.getA2());

        startActivityForResult(carregarUsuario, USUARIO_REQUEST);
    }

    private void carregarAreas(int modo) {

        Intent carregarAreas = new Intent(MainActivity.this, AreasActivity.class);

        //adicionar IF (true = MODE USER = 0, false = MODE rastreador = 1)
        String[] areasFrequentadas = modelo.getAreas(usuario); //PODE SER VAZIO
        //adicionar IF .fim

        ArrayList<MapaDeRiscos> mapas = modelo.getMapas(); //PODE SER VAZIO
        String[] todasAreas = new String[mapas.size()];
        int[] todasAreasAfastado = new int[mapas.size()];

        for (int i = 0; i < mapas.size(); i++) {
            MapaDeRiscos mapa = mapas.get(i);
            todasAreas[i] = mapa.getNome();
            todasAreasAfastado[i] = mapa.getAfastado();
            carregarAreas.putExtra(mapa.getNome(), mapa.getMapa());
        }

        //adicionar IF (true = MODE USER = 0, false = MODE rastreador = 1)
        carregarAreas.putExtra("modo", modo);
        carregarAreas.putExtra("areasFrequentadas", areasFrequentadas);
        carregarAreas.putExtra("nome", usuario);
        //adicionar IF .fim

        carregarAreas.putExtra("todasAreas", todasAreas);
        carregarAreas.putExtra("todasAreasAfastado", todasAreasAfastado);
        startActivityForResult(carregarAreas, AREAS_REQUEST);
    }

    private void carregarStatus() {
        Intent carrStatus = new Intent(MainActivity.this, StatusActivity.class);
        carrStatus.putExtra("usuario", usuario);
        carrStatus.putExtra("status", modelo.getStatus(usuario));
        carrStatus.putExtra("stsFoto", modelo.getStsFoto(usuario));
        startActivityForResult(carrStatus, STATUS_REQUEST);

    }

    private void carregarMensageiro(String usuario) {
        Intent mensageiroIntent = new Intent(MainActivity.this, MensageiroActivity.class);
        mensageiroIntent.putExtra("usuario", usuario);
        mensagens = mensageiro.getMensagens(usuario);
        mensageiroIntent.putExtra("mensagens", mensagens);
        startActivityForResult(mensageiroIntent, MENSAGEIRO_REQUEST);
    }
}