package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class UsuarioActivity extends AppCompatActivity {

    ///CODES:
    public int USUARIO_REQUEST = 2;

    //DO USUARIO:
    private String nome;
    private int status; //0=saudavel; 1=suspeita; 2=doente(confirmado por rastreador)
    private int afastado; //0 = false; >=1 true (apenas rastreador modifica)
    private String stsFoto; // PATH do FILE

    //DO MAPA DO USUARIO:USUARIO_REQUEST
    private int nivelDoRisco;
    private int p0, p1, p2, a0, a1, a2; //contadores
    //  LEGENDA dos "contadores" de possiveis contatos no MAPA - Variaveis p0 ateh a2:
    //  PRESENTE = p; AFASTADO = a
    //  STATUS pessoa ---> 0=saudavel; 1=suspeita; 2=doente (confirmado por rastreador)

    private Button btSair;
    private Button btConfigurar;
    private TextView tvNome;
    private Button btStatus;
    private Button btAfastado;
    private Button btNivelDoRisco;
    private Button btP0;
    private Button btP1;
    private Button btP2;
    private Button btA0;
    private Button btA1;
    private Button btA2;

    private Button btEditarAreas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario);

        Bundle dados = getIntent().getExtras();
        nome = dados.getString("nome");
        status = dados.getInt("status");
        afastado = dados.getInt("afastado");
        stsFoto = dados.getString("stsFoto");

        nivelDoRisco = dados.getInt("nivelDoRisco");
        p0 = dados.getInt("p0");
        p1 = dados.getInt("p1");
        p2 = dados.getInt("p2");
        a0 = dados.getInt("a0");
        a1 = dados.getInt("a1");
        a2 = dados.getInt("a2");

        btSair = (Button) findViewById(R.id.btSair);
        btConfigurar = (Button) findViewById(R.id.btConfigurar);

        tvNome = (TextView) findViewById(R.id.tvNome);
        btStatus = (Button) findViewById(R.id.btStatus);
        btAfastado = (Button) findViewById(R.id.btAfastado);
        btNivelDoRisco = (Button) findViewById(R.id.btNivelDoRisco);
        btP0 = (Button) findViewById(R.id.btP0);
        btP1 = (Button) findViewById(R.id.btP1);
        btP2 = (Button) findViewById(R.id.btP2);
        btA0 = (Button) findViewById(R.id.btA0);
        btA1 = (Button) findViewById(R.id.btA1);
        btA2 = (Button) findViewById(R.id.btA2);

        btEditarAreas = (Button) findViewById(R.id.btEditarAreas);

        ////////////////////////////////////////////////

        tvNome.setText(nome);

        if (afastado == 0) {
            btAfastado.setText("Você está frequentando o campus, siga todos os protocolos.");
            if (status == 0) {
                btStatus.setText("Saudável (0-Verde)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corP0));
            } else if (status == 1) {
                btStatus.setText("Suspeita (1-Amarelo)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corP1));
            } else if (status == 2) {
                btStatus.setText("Doente (2-Vermelho)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corP2));
            }

        } else {
            if (afastado == 1) {
                btAfastado.setText("Você se afastou do campus, muito prudente!");
            } else if (afastado == 2) {
                btAfastado.setText("Você foi afastado do campus por um rastreador.");
            }
            if (status == 0) {
                btStatus.setText("Saudável (0-Verde)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corA0));
            } else if (status == 1) {
                btStatus.setText("Suspeita (1-Amarelo)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corA1));
            } else if (status == 2) {
                btStatus.setText("Doente (2-Vermelho)");
                btStatus.setBackgroundColor(ContextCompat.getColor(this, R.color.corA2));
            }
        }

        if (nivelDoRisco == 0 || afastado > 0) {
            if (afastado > 0) {
                btNivelDoRisco.setText("você está afastado. não sofre risco de infecção no campus");
            } else {
                btNivelDoRisco.setText("risco baixo (nível 0, verde)");
            }
            //btNivelDoRisco.setBackgroundColor(R.color.corP0);
            //btNivelDoRisco.background.colorFilter = BlendModeColorFilter(R.color.corP0, BlendMode.MULTIPLY);
            //btNivelDoRisco.background.setColorFilter(color, PorterDuff.Mode.MULTIPLY);
            btNivelDoRisco.setBackgroundColor(ContextCompat.getColor(this, R.color.corP0));
        } else if (nivelDoRisco == 1) {
            btNivelDoRisco.setText("possível contato com pessoa sob suspeita (nível 1, amarelo)");
            btNivelDoRisco.setBackgroundColor(ContextCompat.getColor(this, R.color.corP1));
        } else {
            btNivelDoRisco.setText("possível contato com pessoa com infecção confirmada (nível 2, vermelho)");
            btNivelDoRisco.setBackgroundColor(ContextCompat.getColor(this, R.color.corP2));
        }

        btP0.setText(String.valueOf(p0));
        btP1.setText(String.valueOf(p1));
        btP2.setText(String.valueOf(p2));
        btA0.setText(String.valueOf(a0));
        btA1.setText(String.valueOf(a1));
        btA2.setText(String.valueOf(a2));


        btSair.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("retorno", "btSair");
                setResult(USUARIO_REQUEST, intent);
                finish();
            }
        });

        btEditarAreas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("retorno", "btEditarAreas");
                setResult(USUARIO_REQUEST, intent);
                finish();
            }
        });

        btStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("retorno", "btStatus");
                setResult(USUARIO_REQUEST, intent);
                finish();
            }
        });

    }
}