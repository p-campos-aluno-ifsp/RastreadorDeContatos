package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class MensagemActivity extends AppCompatActivity {

    private Mensagem mensagem;

    private String deUser;
    private String photoPath;

    private TextView tvRemetenteMsg;
    private Button btConfirmarMensagem;
    private Button btRejeitarMensagem;
    private ImageView ivFotografiaMsg;

    ///CODES:
    private int MENSAGEM_REQUEST = 202;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mensagem);

        Bundle dados = getIntent().getExtras();

        mensagem = (Mensagem) dados.get("mensagem");
        deUser = mensagem.getDe();


        tvRemetenteMsg = (TextView) findViewById(R.id.tvRemetenteMsg);
        btConfirmarMensagem = (Button) findViewById(R.id.btConfirmarMensagem);
        btRejeitarMensagem = (Button) findViewById(R.id.btRejeitarMensagem);
        ivFotografiaMsg = (ImageView) findViewById(R.id.ivFotografiaMsg);

        tvRemetenteMsg.setText(mensagem.getDe());

        photoPath = mensagem.getFotoAnexa();
        File arquivoFotoTemp = new File(photoPath);
        ivFotografiaMsg.setImageURI(Uri.fromFile(arquivoFotoTemp));

        btConfirmarMensagem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mensagem.setLida(true);
                mensagem.setRespostaRastreador(1);

                Intent intent = new Intent();
                intent.putExtra("retorno", 0);
                intent.putExtra("confirmarUser", deUser);
                setResult(MENSAGEM_REQUEST, intent);
                finish();
            }
        });
    }
}