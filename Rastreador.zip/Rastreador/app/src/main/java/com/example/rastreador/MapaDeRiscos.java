package com.example.rastreador;

public class MapaDeRiscos {
//  em pessoa AFASTADO é 0-false; >= 1-true apenas rastreador modifica)
//  LEGENDA dos "contadores" - Variaveis p0 ateh a2:
//  PRESENTE = p; AFASTADO = a
//  STATUS pessoa ---> 0=saudavel; 1=suspeita; 2=doente(confirmado por rastreador)
    private int p0, p1, p2, a0, a1, a2; //contadores
    private String nome;
    private int nivelDoRisco;
    private int afastado; // 0=false; 1=true (como em class Area);

    public MapaDeRiscos(String nome, int afastado) {
        nivelDoRisco = p0 = p1 = p2 = a0 = a1 = a2 = 0;
        this.nome = nome;
        this.afastado = afastado;
    }

    public void contabilizar(int status, int afastado) {
        if (afastado == 0) {
            if (status == 0) {
                p0++;
            } else if (status == 1) {
                p1++;
            } else {
                p2++;
            }
        } else {
            if (status == 0) {
                a0++;
            } else if (status == 1) {
                a1++;
            } else {
                a2++;
            }
        }

        if (p2 != 0) {
            nivelDoRisco = 2;
        } else if (p1 != 0) {
            nivelDoRisco = 1;
        }
    }

    public int[] getMapa() {
        int[] mapa = {nivelDoRisco, p0, p1, p2, a0, a1, a2};
        return mapa;
    }

    public int getAfastado() {
        return afastado;
    }

    public String getNome() {
        return nome;
    }

    public int getNivelDoRisco() {
        return nivelDoRisco;
    }

    public int getP0() {
        return p0;
    }

    public int getP1() {
        return p1;
    }

    public int getP2() {
        return p2;
    }

    public int getA0() {
        return a0;
    }

    public int getA1() {
        return a1;
    }

    public int getA2() {
        return a2;
    }

    public void printMapa() {
        System.out.println("Mapa " + nome + " (qnt=" + (p0 + p1 + p2 + a0 + a1 + a2) + ", risk=" + nivelDoRisco + ") - " + "p0:" + p0 + ";  p1:" + p1 + ";  p2:" + p2 + ";  a0:" + a0 + ";  a1:" + a1 + ";  a2:" + a2);
    }

}
