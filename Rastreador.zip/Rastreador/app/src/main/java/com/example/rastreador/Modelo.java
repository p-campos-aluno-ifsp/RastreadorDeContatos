package com.example.rastreador;

import java.util.ArrayList;

public class Modelo {


    private ArrayList<Area> areas = new ArrayList<>();
    private ArrayList<Pessoa> pessoas = new ArrayList<>();

    public void addArea(String area) {
        Area novaArea = new Area(area);
        if (!areas.contains(novaArea)) {
            areas.add(novaArea);
        } else {
            System.out.println("area \"" + area + "\" foi criada antes");
        }
    }

    public void addPessoa(String pessoa) {
        Pessoa novaPessoa = new Pessoa(pessoa);
        if (!pessoas.contains(novaPessoa)) {
            pessoas.add(novaPessoa);
        } else {
            System.out.println("pessoa \"" + pessoa + "\" ja foi criada antes");
        }

    }

    public void alojarPessoa(String area, String pessoa) {
        Area objArea = new Area(area);
        Pessoa objPessoa = new Pessoa(pessoa);
        if (areas.contains(objArea) && pessoas.contains(objPessoa)) {
            objArea = areas.get(areas.indexOf(objArea));
            objPessoa = pessoas.get(pessoas.indexOf(objPessoa));
            objArea.addPessoa(objPessoa);
            objPessoa.addArea(objArea);
        } else {
            System.out.println("Area ou pessoa nao existe(m), nao foi alojado");
        }
    }

    public void desalojarPessoa(String area, String pessoa) {
        Area objArea = new Area(area);
        Pessoa objPessoa = new Pessoa(pessoa);
        if (areas.contains(objArea) && pessoas.contains(objPessoa)) {
            objArea = areas.get(areas.indexOf(objArea));
            objPessoa = pessoas.get(pessoas.indexOf(objPessoa));
            if (objArea.contem(objPessoa)) {
                objArea.removePessoa(objPessoa);
                objPessoa.removeArea(objArea);
            } else {
                System.out.println("\"" + objArea + "\" e \"" + objPessoa + "\" existem e o 1º NAO contem o 2º, nao foi DESalojado");
            }
        } else {
            System.out.println("Area ou pessoa nao existe(m), nao foi DESalojado");
        }
    }

    public void printAreas() {
        for (Area area : areas) {
            area.printArea();
        }
    }

    public void printPessoas() {
        if (pessoas.isEmpty()) {
            System.out.println("pessoas esta vazio");
            return;
        }
        for (Pessoa pessoa : pessoas) {
            pessoa.printPessoa();
        }
    }

    public boolean contemPessoa(String nome) {
        Pessoa aPessoa = new Pessoa(nome);
        return pessoas.contains(aPessoa);
    }

    public Pessoa getPessoa(String nome) {
        Pessoa aPessoa = new Pessoa(nome);
        if (pessoas.contains(aPessoa)) {
            aPessoa = pessoas.get(pessoas.indexOf(aPessoa));
        } else {
            System.out.println("getPessoa: pessoa nao existe no modelo. Nao retornada");
            return null;
        }
        return aPessoa;
    }

    public void printPessoaMapa(String nome) {
        Pessoa aPessoa = new Pessoa(nome); ///SUBISTITUIR POR getMapa()???
        MapaDeRiscos mapa;
        if (pessoas.contains(aPessoa)) {
            aPessoa = pessoas.get(pessoas.indexOf(aPessoa));
        } else {
            System.out.println("printPessoaMapa: pessoa nao existe no modelo");
            return;
        }
        mapa = aPessoa.getMapa();
        mapa.printMapa();
    }

    public String[] getPessoasString() {
        String arrrayPessoas[] = new String[pessoas.size()];
        int i = 0;
        for (Pessoa pessoa : pessoas) {
            arrrayPessoas[i] = pessoa.toString();
            i++;
        }
        return arrrayPessoas;
    }

    public ArrayList<Pessoa> getPessoas() {
        return pessoas;
    }

    public MapaDeRiscos getPessoaMapa(String nome) {
        Pessoa aPessoa = new Pessoa(nome); ///SUBISTITUIR POR getMapa()????
        MapaDeRiscos mapa = new MapaDeRiscos("vazio", 0);
        if (pessoas.contains(aPessoa)) {
            aPessoa = pessoas.get(pessoas.indexOf(aPessoa));
        } else {
            System.out.println("getPessoaMapa: pessoa nao existe no modelo");
            return mapa;
        }
        mapa = aPessoa.getMapa();
        return mapa;
    }

    public String[] getAreas(String nome) {
        Pessoa aPessoa = new Pessoa(nome);
        // if (pessoas.contains(aPessoa)) { // ja foi CHECADO em LOGIN???
        aPessoa = pessoas.get(pessoas.indexOf(aPessoa));
        return aPessoa.getAreas();
    }

    public ArrayList<MapaDeRiscos> getMapas() {
        ArrayList<MapaDeRiscos> mapas = new ArrayList<>();
        MapaDeRiscos mapa;
        ArrayList<Pessoa> pessoas = new ArrayList<>();

        for (Area area : areas) {
            mapa = new MapaDeRiscos(area.toString(), area.getAfastado());
            pessoas = area.getPessoas();

            for (Pessoa pessoa : pessoas) {
                mapa.contabilizar(pessoa.getStatus(), pessoa.getAfastado());
            }

            mapas.add(mapa);
        }
        return mapas;
    }


    /// FALTA ? MODO RASTREADOR pois 0=false; 1=true; 2=true+só rastreador insere ou remove
    public void afastarPessoa(String nome) {
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));
            pessoa.setAfastado(1);
        } else {
            System.out.println("Modelo.afastarPessoa - Pessoa nao existe, nao foi afastada");
        }
    }

    public void afastarArea(String areaNome) {
        ///pessoa.afastado  = mais um
        /////INCOMPLETO, precisa modelar p/ considerar que para cada area afastada "pessoa.afastado += 1"
        Area area = new Area(areaNome);
        if (areas.contains(area)) {
            area = areas.get(areas.indexOf(area));
            area.setAfastado(1);
            ArrayList<Pessoa> afastarPessoas = area.getPessoas();

            for (Pessoa pessoa : afastarPessoas) { ///<PESSOA> PODE SER VAZIO
                //   if (pessoa.getAfastado() == 0) {
                pessoa.setAfastado(2);
                //   } else {

                //   }
            }


        } else {
            System.out.println("afastarArea: nome da area nao encontrado no modelo");
        }


    }

    public void desafastarArea(String areaNome) {
        ///pessoa.afastado  = menos um
        /////INCOMPLETO, precisa modelar p/ considerar que para cada area DESafastada "pessoa.afastado -= 1"
    }

    public int getStatus(String nome) {
        Pessoa pessoaTemp = getPessoa(nome);
        return pessoaTemp.getStatus();
    }

    //  PARA USO DA CLASSE MODELO (private) - RN: 0=saudavel; 1=suspeita; 2=doente+só rastreador insere
    private void setStatus(String nome, int status) {
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));

            pessoa.setStatus(status);
            pessoa.setStsFoto("0");
        } else {
            System.out.println("Modelo.setStatus - Pessoa nao existe, nao foi setada");
        }
    }

    // PARA USO NO MODO USUARIO - RN: 0=saudavel; 1=suspeita; 2=doente+só rastreador insere
    public boolean setStatusUsuario(String nome, int status) {
        if (status > 1) {
            System.out.println("Modelo.setStatusUsuario: se Status > 1 deve informar tbm path de doc. Sts nao foi alterado");
            return false;
        }
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));
            String stsFoto = pessoa.getStsFoto();

            if (!stsFoto.equals("0")) { // String com caracter do numero ZERO
                System.out.println("Modelo.setStatusUsuario: Pessoa informou sts 3-Doente e enviou DOC, deve aguardar confirmação de um rastreador para alterar");
                return false;
            }
            pessoa.setStatus(status);

            return true;
        } else {
            System.out.println("Modelo.setStatus - Pessoa nao existe, nao foi setada");
        }
        return false;
    }

    // PARA USO NO MODO USUARIO - RN: 0=saudavel; 1=suspeita; 2=doente+só rastreador insere
    public boolean setStatusUsuario(String nome, int status, String stsFoto) {
        if (status != 2) {
            System.out.println("Modelo.setStatusUsuario2: Status != 2  se informar path de doc o sts correto é 2. Sts nao foi alterado");
            return false;
        }
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));

            pessoa.setStatus(1); //1,sob suspeita, pois trava ate rastreador confirmar msg para sts="2-doente"
            pessoa.setStsFoto(stsFoto);

            return true;
        } else {
            System.out.println("Modelo.setStatus - Pessoa nao existe, nao foi setada");
        }
        return false;
    }

    // PARA USO NO MODO RASTREADOR - RN: 0=saudavel; 1=suspeita; 2=doente+só rastreador insere
    public boolean setStatusRastreador(String nome, int status) {
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));
            if (status == 2) { //2-doente confirmado por um rastreador, se nao mantem=1 mas permite prox. escolha user 0 ou 1 etc...
                pessoa.setStatus(2);
            } else {
                pessoa.setStatus(status);
            }
            pessoa.setStsFoto("0");//limpou, user pode mudar novamente.
            return true;
        } else {
            System.out.println("Modelo.setStatus - Pessoa nao existe, nao foi setada");
        }
        return false;
    }

    public String getStsFoto(String nome) {
        Pessoa pessoaTemp = getPessoa(nome);
        return pessoaTemp.getStsFoto();
    }

    // FALTA ? MODO RASTREADOR pois 0=saudavel; 1=suspeita; 2=doente+só rastreador insere
    public void setStsFoto(String nome, int status) {
        Pessoa pessoa = new Pessoa(nome);
        if (pessoas.contains(pessoa)) {
            pessoa = pessoas.get(pessoas.indexOf(pessoa));
            pessoa.setStatus(status);
        } else {
            System.out.println("Modelo.setStatus - Pessoa nao existe, nao foi setada");
        }
    }


    
    ////DADOS DO MODELO
    public void carregarDados() {
        addArea("Area1");
        addArea("Area2");
        addArea("Area3");
        addArea("Area4");

        addPessoa("a");
        setStatus("a", 0);
        afastarPessoa("a");

        addPessoa("b");
        setStatus("b", 2);
        afastarPessoa("b");

        addPessoa("c");
        setStatus("c", 0);

        addPessoa("d");
        setStatus("d", 2);

        addPessoa("e");
        setStatus("e", 1);
        afastarPessoa("e");

        addPessoa("f");
        setStatus("f", 1);

        addPessoa("g");
        setStatus("g", 1);
        afastarPessoa("g");

        addPessoa("h");
        setStatus("h", 2);

        alojarPessoa("Area1", "a");
        alojarPessoa("Area1", "b");
        alojarPessoa("Area1", "c");

        alojarPessoa("Area2", "b");
        alojarPessoa("Area2", "c");
        alojarPessoa("Area2", "f");
        alojarPessoa("Area2", "g");

        alojarPessoa("Area3", "a");
        alojarPessoa("Area3", "d");
        alojarPessoa("Area3", "e");

        alojarPessoa("Area4", "h");

        afastarArea("Area4");
    }
}
