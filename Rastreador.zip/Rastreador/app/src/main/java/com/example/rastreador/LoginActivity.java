package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    ///CODES:
    public int LOGIN_REQUEST = 1;
    private String[] usuarios;
    private TextView etNome;
    private Button btEntrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Bundle dados = getIntent().getExtras();
        usuarios = dados.getStringArray("usuarios");

        etNome = (EditText) findViewById(R.id.etNome);

        btEntrar = (Button) findViewById(R.id.btEntrar);

        btEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String nome = etNome.getText().toString();

                String usuario = "VAZIO";

                if (!nome.equals("rastreador")) {
                    for (int i = 0; i < usuarios.length; i++) {
                        if (nome.equals(usuarios[i])) {
                            usuario = usuarios[i];
                            break;
                        }
                    }
                } else {
                    usuario = "rastreador";
                }

                if (usuario.equals("VAZIO")) {
                    Toast.makeText(LoginActivity.this, "Usuario não encontrado, verifique o nome.", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = new Intent();
                    intent.putExtra("retorno", usuario);
                    setResult(LOGIN_REQUEST, intent);
                    finish();
                }
            }
        });
    }
}