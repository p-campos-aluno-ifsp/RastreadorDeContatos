package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;

public class MensageiroActivity extends AppCompatActivity {

    private LinearLayout listaMensagens;

    private Button btTeste;
    private Button btVoltarMsg;

    private String usuario;
    public ArrayList<Mensagem> mensagens;
    public Mensagem mensagem;
    private ScrollView scScrollView;

    ///CODES:
    private int MENSAGEIRO_REQUEST = 5;
    private int MENSAGEM_REQUEST = 202;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mensageiro);


        Bundle dados = getIntent().getExtras();
        usuario = dados.getString("usuario");
        //mensagens = dados.getParcelableArrayList("mensagens");
        mensagens = (ArrayList) dados.get("mensagens");

        btVoltarMsg = (Button) findViewById(R.id.btVoltarMensageiro);


        scScrollView = (ScrollView) findViewById(R.id.scScrollView);

        //  listaMensagens = (LinearLayout) findViewById(R.id.listaMensagens);
        listaMensagens = new LinearLayout(this);
        listaMensagens.setOrientation(LinearLayout.VERTICAL);
        scScrollView.addView(listaMensagens);

        btVoltarMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.putExtra("retorno", 2); // 1 = fechar
                setResult(MENSAGEIRO_REQUEST, intent);
                finish();
            }
        });

        carregarMensagens();

    }

    private void carregarMensagens() {

        ArrayList<Button> btArray = new ArrayList<>();

        for (int i = 0; i < mensagens.size(); i++) {
            Mensagem novaMensagem = mensagens.get(i);
            int tipoDeMensagem = novaMensagem.getTipo();
            boolean lida = novaMensagem.isLida();

            Button novoBotao = new Button(this);

            String numMsg = "";
            if ((i + 1) < 10) {
                numMsg += "0";
            }
            numMsg += String.valueOf(i + 1);

            if (tipoDeMensagem == 1) {
                novoBotao.setText(numMsg + ". confirmar doente: " + novaMensagem.getDe());
            }

            if (lida) {
                novoBotao.setBackgroundColor(ContextCompat.getColor(this, R.color.corMsgLida));
            } else {
                novoBotao.setBackgroundColor(ContextCompat.getColor(this, R.color.corMsgNaoLida));
            }

            novoBotao.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    abrirMensagem(getIndexBtMensagens(view));
                }
            });
            btArray.add(novoBotao);
        }

        for (int i = 0; i < btArray.size(); i++) {
            Button umBotao = btArray.get(i);
            listaMensagens.addView(umBotao);
        }
    }

    public void abrirMensagem(int indexMensagens) {
        mensagem = mensagens.get(indexMensagens);

        Intent abrirMensagemIntent = new Intent(MensageiroActivity.this, MensagemActivity.class);
        //   abrirMensagemIntent.putExtra("usuario", usuario);
        abrirMensagemIntent.putExtra("mensagem", mensagem);

        startActivityForResult(abrirMensagemIntent, MENSAGEM_REQUEST);
    }

    public int getIndexBtMensagens(View view) {
        Button esseBotao = (Button) view;
        String txtBotao = String.valueOf(esseBotao.getText());
        int intDezena = Integer.valueOf(String.valueOf(txtBotao.charAt(0)));
        int intUnidade = Integer.valueOf(String.valueOf(txtBotao.charAt(1)));
        int indexMensagens = ((intDezena * 10) + intUnidade) - 1;
        return indexMensagens;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
//        if (resultCode == Activity.RESULT_CANCELED) {
//            finish();
        if (requestCode == MENSAGEM_REQUEST) {
            /// add if retorno = 0
            String deUser = data.getStringExtra("confirmarUser");

            Intent intent = new Intent();
            intent.putExtra("retorno", 1); // 1 = fechar e reabrir
            intent.putExtra("confirmarUser", deUser);

            setResult(MENSAGEIRO_REQUEST, intent);
            finish();
        }
    }
}