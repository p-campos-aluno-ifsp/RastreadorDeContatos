package com.example.rastreador;

import android.os.Parcel;
import android.os.Parcelable;

public class Mensagem implements Parcelable {

    private String de;
    private String para;
    private int tipo; //1=fotoDoc Confirmar doente (para rastreador);
    private String txtMsg;
    private String fotoAnexa;
    private boolean lida;
    private int respostaRastreador; //0=vazio / 1=confirmado / 2=rejeitado

    public Mensagem(String de, String para, int tipo, String txtMsg, String fotoAnexa) {
        this.de = de;
        this.para = para;
        this.tipo = tipo;
        this.txtMsg = txtMsg;
        this.fotoAnexa = fotoAnexa;
        this.lida = false;
        this.respostaRastreador = 0;
    }

    public Mensagem(String de, String para, int tipo, String txtMsg) {
        this.de = de;
        this.para = para;
        this.tipo = tipo;
        this.txtMsg = txtMsg;
        this.fotoAnexa = "0";
        this.lida = false;
        this.respostaRastreador = 0;
    }

    protected Mensagem(Parcel in) {
        de = in.readString();
        para = in.readString();
        tipo = in.readInt();
        txtMsg = in.readString();
        fotoAnexa = in.readString();
        lida = in.readByte() != 0;
        respostaRastreador = in.readInt();
    }

    public static final Creator<Mensagem> CREATOR = new Creator<Mensagem>() {
        @Override
        public Mensagem createFromParcel(Parcel in) {
            return new Mensagem(in);
        }

        @Override
        public Mensagem[] newArray(int size) {
            return new Mensagem[size];
        }
    };

    public void setLida(boolean lida) {
        this.lida = lida;
    }

    public void setRespostaRastreador(int respostaRastreador) {
        this.respostaRastreador = respostaRastreador;
    }

    public String getDe() {
        return de;
    }

    public String getPara() {
        return para;
    }

    public int getTipo() {
        return tipo;
    }

    public String getTxtMsg() {
        return txtMsg;
    }

    public String getFotoAnexa() {
        return fotoAnexa;
    }

    public boolean isLida() {
        return lida;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(de);
        parcel.writeString(para);
        parcel.writeInt(tipo);
        parcel.writeString(txtMsg);
        parcel.writeString(fotoAnexa);
        parcel.writeByte((byte) (lida ? 1 : 0));
        parcel.writeInt(respostaRastreador);
    }
}
