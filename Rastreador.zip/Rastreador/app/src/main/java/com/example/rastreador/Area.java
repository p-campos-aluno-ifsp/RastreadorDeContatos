package com.example.rastreador;

import java.util.ArrayList;

public class Area {

    private String nome;
    private int afastado; // 0=false; 1=true;
    private ArrayList<Pessoa> pessoas = new ArrayList<>();

    public Area(String nome) {
        this.nome = nome;
        this.afastado = 0;
    }

    public void addPessoa(Pessoa pessoa) {
        if (!pessoas.contains(pessoa)) { // checar em Modelo????
            this.pessoas.add(pessoa);
        } else {
            //System.out.println("pessoa \"" + pessoa + "\" já está nesta sala");
        }
    }

    public void removePessoa(Pessoa pessoa) {
        if (pessoas.contains(pessoa)) {
            this.pessoas.remove(pessoa);
        } else {
            //System.out.println("pessoa \"" + pessoa + "\" NÂO está nesta sala");
        }
    }

    public boolean contem(Pessoa pessoa) {
        return pessoas.contains(pessoa);
    }

    public ArrayList<Pessoa> getPessoas() {
        return pessoas;
    }

    public void printArea() {
        System.out.print(this.nome + ": ");
        for (Pessoa pessoa : pessoas) {
            System.out.print(pessoa + "; ");
        }
        System.out.print("\n");
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getAfastado() {
        return afastado;
    }

    public void setAfastado(int afastado) {
        this.afastado = afastado;
    }

    @Override
    public boolean equals(Object area) {
        return this.nome.equals(area.toString());
    }

    @Override
    public String toString() {
        return nome;
    }

}
