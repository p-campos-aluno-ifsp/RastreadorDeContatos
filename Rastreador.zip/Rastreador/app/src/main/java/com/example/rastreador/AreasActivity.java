package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class AreasActivity extends AppCompatActivity {

    private TextView tvTeste;
    private Button btTeste;
    private int modo; //0=usuario, 1=rastreador

    ///CODES:
    public int AREAS_REQUEST = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_areas);

        tvTeste = (TextView) findViewById(R.id.tvTeste);
        btTeste = (Button) findViewById(R.id.btTeste);

        String resultado = "";

        Bundle dados = getIntent().getExtras();

        String nome = dados.getString("nome");
        resultado += "UsuarioNome:" + nome + "; ";

        modo = dados.getInt("modo");
        resultado += "Modo:" + modo + "; ";

        String[] todasAreas = dados.getStringArray("todasAreas");
        resultado += "todasAreas:";
        for (int i = 0; i < todasAreas.length; i++) {
            resultado += (todasAreas[i] + "; ");
        }

        int[] todasAreasAfastado = dados.getIntArray("todasAreasAfastado");
        resultado += "todasAreasAfastado:";
        for (int i = 0; i < todasAreasAfastado.length; i++) {
            resultado += String.valueOf(todasAreasAfastado[i]) + "; ";
        }

        for (int i = 0; i < todasAreas.length; i++) {
            int[] mapa = dados.getIntArray(todasAreas[i]);
            resultado += todasAreas[i] + "(mapa) = nivelDoRisco:" + String.valueOf(mapa[0]) + "; ";
            resultado += "p0:" + String.valueOf(mapa[1]) + "; " +
                    "p1:" + String.valueOf(mapa[2]) + "; " +
                    "p2:" + String.valueOf(mapa[3]) + "; " +
                    "a0:" + String.valueOf(mapa[4]) + "; " +
                    "a1:" + String.valueOf(mapa[5]) + "; " +
                    "a2:" + String.valueOf(mapa[6]) + "; ";
        }


        if (modo == 0) {

            resultado += "todos arrays anteriores estao na ordem pelo mesmo index [i], o proximo NAO, eh apenas a lista de salas frequentadas por UM usuario. ";

            String[] areasFrequentadas = dados.getStringArray("areasFrequentadas");
            resultado += "areasFrequentadas:";
            for (int i = 0; i < areasFrequentadas.length; i++) {
                resultado += areasFrequentadas[i] + "; ";
            }
        }

        tvTeste.setText(resultado);

        btTeste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                /// Retornar um array String[] de nomes de salas que USUARIO deixou checadas
                //  Retornar tbm o MODO!!!
                /// Se pessoa - checa apenas areas que frequenta
                /// Se rastreador - checa apenas areas afastadas
                /// Exemplo:
                String[] arrayAreas = {"Area1", "Area2"};

                Intent intent = new Intent();
                intent.putExtra("arrayAreas", arrayAreas);
                intent.putExtra("modo", modo);

                setResult(AREAS_REQUEST, intent);
                finish();
            }
        });

    }
}