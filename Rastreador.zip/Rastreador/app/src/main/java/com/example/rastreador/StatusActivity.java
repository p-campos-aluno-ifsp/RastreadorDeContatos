package com.example.rastreador;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StatusActivity extends AppCompatActivity {

    private String usuario;
    private int status;
    private String stsFoto;
    private int statusSelecionado;

    private ImageView ivFotografia;
    private Button btFotografar;
    private Button btConfirmar;
    private Button btStsSaudavel;
    private Button btStsSuspeita;
    private Button btCancelar;
    private Button btStsDoente;

    private String currentPhotoPath;
    private File photoFile;
    private Uri photoURI;

    ///CODES:
    public int STATUS_REQUEST = 4;
    private static final int REQUEST_IMAGE_CAPTURE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_status);

        Bundle dados = getIntent().getExtras();
        usuario = dados.getString("usuario");
        status = dados.getInt("status");
        stsFoto = dados.getString("stsFoto");

        ivFotografia = (ImageView) findViewById(R.id.ivFotografia);
        btFotografar = (Button) findViewById(R.id.btFotografar);
        btConfirmar = (Button) findViewById(R.id.btConfirmar);
        btStsSaudavel = (Button) findViewById(R.id.btStsSaudavel);
        btStsSuspeita = (Button) findViewById(R.id.btStsSuspeita);
        btStsDoente = (Button) findViewById(R.id.btStsDoente);
        btCancelar = (Button) findViewById(R.id.btCancelar);


        if (stsFoto.equals("0")) {
            photoFile = null;
        } else {
            photoFile = new File(stsFoto);
        }

        statusSelecionado = -1; //-1=nenhuma escolha Ou cancelarClick

        if (!stsFoto.equals("0") && status == 1) {
            btConfirmar.setBackgroundColor(ContextCompat.getColor(this, R.color.corP2));
            btConfirmar.setVisibility(View.VISIBLE);

            btConfirmar.setEnabled(false);
            btStsSaudavel.setEnabled(false);
            btStsSuspeita.setEnabled(false);
            btStsDoente.setEnabled(false);

            btFotografar.setVisibility(View.GONE);
            ivFotografia.setVisibility(View.VISIBLE);
            ivFotografia.setImageURI(Uri.fromFile(photoFile));
            btCancelar.setText("aguardando análise do documento - voltar");
        }

    }

    public void fotografarClick(View view) {
        Intent fotografarIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (fotografarIntent.resolveActivity(getPackageManager()) != null) {

            photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException ex) {
                Toast.makeText(StatusActivity.this, "Não foi possível criar arquivo na memória", Toast.LENGTH_LONG).show();
            } //// com.example.android.rastreador
            if (photoFile != null) {
                photoURI = FileProvider.getUriForFile(this,
                        "com.example.android.rastreador.fileprovider",
                        photoFile);
                fotografarIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(fotografarIntent, REQUEST_IMAGE_CAPTURE);
            }   //////// ref: https://developer.android.com/training/camera/photobasics?hl=pt-br
        } else {
            Toast.makeText(StatusActivity.this, "Não foi encontrada aplicação para usar câmera", Toast.LENGTH_LONG).show();
        }
    }


    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "DOCrast_" + timeStamp;

        File storageDir = getFilesDir();

        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        //  if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {//   Bundle extras = data.getExtras();//   Bitmap imageBitmap = (Bitmap) extras.get("data");//   ivFotografia.setImageBitmap(imageBitmap);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK && photoFile.exists()) {
            File arquivoTemp = new File(currentPhotoPath);
            ivFotografia.setImageURI(Uri.fromFile(arquivoTemp));
        } else {
            photoFile = null;
        }

    }

    public void saudavelClick(View view) {
        statusSelecionado = 0;
        btConfirmar.setBackgroundColor(ContextCompat.getColor(this, R.color.corP0));
        btConfirmar.setVisibility(View.VISIBLE);
        btFotografar.setVisibility(View.GONE);
        ivFotografia.setVisibility(View.GONE);
    }

    public void suspeitaClick(View view) {
        statusSelecionado = 1;
        btConfirmar.setBackgroundColor(ContextCompat.getColor(this, R.color.corP1));
        btConfirmar.setVisibility(View.VISIBLE);
        btFotografar.setVisibility(View.GONE);
        ivFotografia.setVisibility(View.GONE);
    }

    public void doenteClick(View view) {
        statusSelecionado = 2;
        btConfirmar.setBackgroundColor(ContextCompat.getColor(this, R.color.corP2));
        btConfirmar.setVisibility(View.VISIBLE);
        btFotografar.setVisibility(View.VISIBLE);
        ivFotografia.setVisibility(View.VISIBLE);
    }

    public void confirmarClick(View view) {
        Intent intent = new Intent();

        if (statusSelecionado == -1) {
            Toast.makeText(StatusActivity.this, "Para confirmar selecione uma opção primeiro", Toast.LENGTH_LONG).show();
            return;
        } else if (statusSelecionado == 2) {
            if (photoFile == null) {
                Toast.makeText(StatusActivity.this, "Para escolher o status doente é preciso anexar o documento do exame e confirmar", Toast.LENGTH_LONG).show();
                return;
            } else {
                intent.putExtra("fotoPath", currentPhotoPath);
            }
        }
        intent.putExtra("retorno", statusSelecionado);
        setResult(STATUS_REQUEST, intent);
        finish();
    }

    public void cancelarClick(View view) {
        statusSelecionado = -1;
        Intent intent = new Intent();
        intent.putExtra("retorno", statusSelecionado);
        setResult(STATUS_REQUEST, intent);
        finish();
    }
}