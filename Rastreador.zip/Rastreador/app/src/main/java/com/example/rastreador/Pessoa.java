package com.example.rastreador;

import java.util.ArrayList;
import java.util.HashSet;

public class Pessoa {

    private String nome;
    private int afastado; //0 = false; >= 1 significa "true + apenas rastreador modifica"
    // ?? sera que dev alterar afastado para ?? ou dividir afastado em AfastUser afastRastreador??  0 = false; -1 = true; >1 = true+(apenas rastreador modifica)
    private int status; //0=saudavel; 1=suspeita; 2=doente(confirmado por rastreador)
    private String stsFoto;

    private ArrayList<Area> areas;

    public Pessoa(String nome) {
        this.nome = nome;
        this.afastado = 0;
        this.status = 0;
        this.stsFoto = "0";
        this.areas = new ArrayList<Area>();
    }

    public void addArea(Area area) {
        if (!areas.contains(area)) { //checar em Modelo????
            this.areas.add(area);
        } else {
            System.out.println("area \"" + area + "\" já contem esta pessoa");
        }
    }

    public void removeArea(Area area) {
        if (areas.contains(area)) { // checar em Modelo?
            this.areas.remove(area);
        } else {
            System.out.println("area \"" + area + "\" NÂO contem esta pessoa");
        }
    }

    public MapaDeRiscos getMapa() {
        MapaDeRiscos mapa = new MapaDeRiscos(nome, 0);
        ArrayList<Pessoa> pessoas;
        HashSet<Pessoa> pessoasUnicas = new HashSet<>();

        for (Area area : areas) {
            pessoas = area.getPessoas();
            pessoasUnicas.addAll(pessoas);
        }

        pessoasUnicas.remove(this);

        for (Pessoa pessoa : pessoasUnicas) {
            mapa.contabilizar(pessoa.getStatus(), pessoa.getAfastado());
        }

        return mapa;
    }

    public String[] getAreas() {
        String[] areasNomes = new String[areas.size()];
        for (int i = 0; i< areas.size(); i++){
            Area area = areas.get(i);
            areasNomes[i] = area.toString();
        }
        return areasNomes;
    }

    @Override
    public boolean equals(Object pessoa) {
        return this.nome.equals(pessoa.toString());
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public void setStsFoto(String stsFoto) {
        this.stsFoto = stsFoto;
    }

    public void setAfastado(int afastado) {
        this.afastado = afastado;
    }

    public String toString() {
        return nome;
    }

    public int getStatus() {
        return status;
    }

    public int getAfastado() {
        return afastado;
    }

    public String getStsFoto() {
        return stsFoto;
    }

    public void printPessoa() {
        System.out.print(nome + ": ");
        for (Area area : areas) {
            System.out.print(area + "; ");
        }
        System.out.print("\n");
    }
}
